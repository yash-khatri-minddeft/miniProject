const { ethers } = require('hardhat');
describe("Product", () => {
  var LOL, Token, owner, accounts;
  beforeEach(async () => {
    [owner, ...accounts] = await ethers.getSigners();
    Token = await( await ethers.getContractFactory('LOLToken')).deploy();
    LOL = await (await ethers.getContractFactory('LOLX')).deploy(Token.address);
  })
  describe('test case', async () => {
    it('check product details added', async () => {
      const tx = await LOL.addProduct(101,"product 1", 200, "https://miro.medium.com/v2/resize:fit:640/0*XX86UHYVB1X0dmxE","This is a good product", "Shaitan gali, khatra mahal, andher nagar",true);
      const tx2 = await LOL.connect(accounts[0]).addProduct(102,"product 2", 400, "https://miro.medium.com/v2/resize:fit:640/0*XX86UHYVB1X0dmxE","This is a 2nd product", "Shaitan gali, khatra mahal, andher nagar ke paas",false);
      // console.log(await LOL.getProduct(101))
      // console.log(await LOL.getProduct(102))

      const makeOffer = await LOL.connect(accounts[0]).makeOffer(101, 102, 190)
      // console.log(await LOL.offers(101))

      const makeOffer2 = await LOL.connect(accounts[3]).makeOffer(102, 102, 20)
      console.log(await LOL.offers(102))

      await Token.connect(accounts[3]).mint(10000,{value: ethers.utils.parseEther("0.1")})
      await Token.connect(accounts[3]).approve(LOL.address, ethers.utils.parseEther("10000"))
      console.log(await LOL.connect(accounts[3]).getToken())
      console.log(await LOL.offers(102))
      await LOL.connect(accounts[3]).claimOfferWithEth(102,{value: ethers.utils.parseEther("200")})
      // console.log(await Token.balanceOf(owner.address))
      // console.log(await Token.balanceOf(accounts[3].address))
      console.log(ethers.utils.formatEther((await accounts[0].getBalance())))
      console.log(ethers.utils.formatEther((await accounts[3].getBalance())))
    })
  })
});
